﻿#region File Description
//-----------------------------------------------------------------------------
// This program show GeonBit.UI examples and usage.
//
// GeonBit.UI is an export of the UI system used for GeonBit (an open source 
// game engine in MonoGame) and is free to use under the MIT license.
//
// To learn more about GeonBit.UI, you can visit the git repo:
// https://github.com/RonenNess/GeonBit.UI
//
// Or explore the different README files scattered in the solution directory. 
//
// Author: Ronen Ness.
// Since: 2016.
//-----------------------------------------------------------------------------
#endregion

// using MonoGame and basic system stuff
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

// using GeonBit UI elements
using GeonBit.UI.Entities;
using GeonBit.UI.Entities.TextValidators;
using GeonBit.UI.DataTypes;
using GeonBit.UI.Utils.Forms;
using GeonBit.UI.Utils;
using System.Diagnostics;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Threading;

namespace GeonBit.UI.Examples
{
    /// <summary>
    /// GeonBit.UI.Example is just an example code. Everything here is not a part of the GeonBit.UI framework, but merely an example of how to use it.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }

    /// <summary>
    /// This is the main 'Game' instance for your game.
    /// </summary>
    public class GeonBitUI_Examples : Game
    {
        // graphics and spritebatch
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Socket server;
        Thread atender;

        bool conectado = false;

        // all the example panels (screens)
        List<Panel> panels = new List<Panel>();

        // buttons to rotate examples
        Button nextExampleButton;
        Button previousExampleButton;

        // paragraph that shows the currently active entity
        Paragraph targetEntityShow;

        // current example shown
        int currExample = 0;

        // current theme
        BuiltinThemes _currTheme;

        /// <summary>
        /// Create the game instance.
        /// </summary>
        public GeonBitUI_Examples()
        {
            // init graphics device manager and set content root
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            Window.IsBorderless = true;
        }

        /// <summary>
        /// Initialize the main application.
        /// </summary>
        protected override void Initialize()
        {
            // make the window fullscreen (but still with border and top control bar)
            int _ScreenWidth = graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Width;
            int _ScreenHeight = graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Height;
            graphics.PreferredBackBufferWidth = (int)_ScreenWidth;
            graphics.PreferredBackBufferHeight = (int)_ScreenHeight;
            graphics.IsFullScreen = false;
            graphics.ApplyChanges();

            // init theme and ui
            InitializeThemeAndUI(BuiltinThemes.hd);
        }

        private void InitializeThemeAndUI(BuiltinThemes theme)
        {
            // clear previous panels
            panels.Clear();

            // store current theme
            _currTheme = theme;

            // create and init the UI manager
            UserInterface.Initialize(Content, theme);
            UserInterface.Active.UseRenderTarget = true;

            // draw cursor outside the render target
            UserInterface.Active.IncludeCursorInRenderTarget = false;

            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = spriteBatch ?? new SpriteBatch(GraphicsDevice);

            // init ui and examples
            InitExamplesAndUI();
        }

        /// <summary>
        /// Create the top bar with next / prev buttons etc, and init all UI example panels.
        /// </summary>        
        protected void InitExamplesAndUI()
        {
            // will init examples only if true
            bool initExamples = true;

            // create top panel
            int topPanelHeight = 65;
            Panel topPanel = new Panel(new Vector2(0, topPanelHeight + 2), PanelSkin.Simple, Anchor.TopCenter);
            topPanel.Padding = Vector2.Zero;
            UserInterface.Active.AddEntity(topPanel);
            topPanel.Visible = false;

            // add previous example button
            previousExampleButton = new Button("<- Back", ButtonSkin.Default, Anchor.Auto, new Vector2(300, topPanelHeight));
            previousExampleButton.OnClick = (Entity btn) => { };
            topPanel.AddChild(previousExampleButton);


            // add next example button
            nextExampleButton = new Button("Next ->", ButtonSkin.Default, Anchor.TopRight, new Vector2(300, topPanelHeight));
            nextExampleButton.OnClick = (Entity btn) => { };
            nextExampleButton.Identifier = "next_btn";
            topPanel.AddChild(nextExampleButton);

            // events panel for debug
            Panel eventsPanel = new Panel(new Vector2(400, 530), PanelSkin.Simple, Anchor.CenterLeft, new Vector2(-10, 0));
            eventsPanel.Visible = false;

            // events log (single-time events)
            eventsPanel.AddChild(new Label("Events Log:"));
            SelectList eventsLog = new SelectList(size: new Vector2(-1, 280));
            eventsLog.ExtraSpaceBetweenLines = -8;
            eventsLog.ItemsScale = 0.5f;
            eventsLog.Locked = true;
            eventsPanel.AddChild(eventsLog);

            // current events (events that happen while something is true)
            eventsPanel.AddChild(new Label("Current Events:"));
            SelectList eventsNow = new SelectList(size: new Vector2(-1, 100));
            eventsNow.ExtraSpaceBetweenLines = -8;
            eventsNow.ItemsScale = 0.5f;
            eventsNow.Locked = true;
            eventsPanel.AddChild(eventsNow);

            // paragraph to show currently active panel
            targetEntityShow = new Paragraph("test", Anchor.Auto, Color.White, scale: 0.75f);
            eventsPanel.AddChild(targetEntityShow);

            // add the events panel
            UserInterface.Active.AddEntity(eventsPanel);

            // whenever events log list size changes, make sure its not too long. if it is, trim it.
            eventsLog.OnListChange = (Entity entity) =>
            {
                SelectList list = (SelectList)entity;
                if (list.Count > 100)
                {
                    list.RemoveItem(0);
                }
            };

            // listen to all global events - one timers
            UserInterface.Active.OnClick = (Entity entity) => { eventsLog.AddItem("Click: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnRightClick = (Entity entity) => { eventsLog.AddItem("RightClick: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnMouseDown = (Entity entity) => { eventsLog.AddItem("MouseDown: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnRightMouseDown = (Entity entity) => { eventsLog.AddItem("RightMouseDown: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnMouseEnter = (Entity entity) => { eventsLog.AddItem("MouseEnter: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnMouseLeave = (Entity entity) => { eventsLog.AddItem("MouseLeave: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnMouseReleased = (Entity entity) => { eventsLog.AddItem("MouseReleased: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnMouseWheelScroll = (Entity entity) => { eventsLog.AddItem("Scroll: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnStartDrag = (Entity entity) => { eventsLog.AddItem("StartDrag: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnStopDrag = (Entity entity) => { eventsLog.AddItem("StopDrag: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnFocusChange = (Entity entity) => { eventsLog.AddItem("FocusChange: " + entity.GetType().Name); eventsLog.scrollToEnd(); };
            UserInterface.Active.OnValueChange = (Entity entity) => { if (entity.Parent == eventsLog) { return; } eventsLog.AddItem("ValueChanged: " + entity.GetType().Name); eventsLog.scrollToEnd(); };

            // clear the current events after every frame they were drawn
            eventsNow.AfterDraw = (Entity entity) => { eventsNow.ClearItems(); };

            // listen to all global events - happening now
            UserInterface.Active.WhileDragging = (Entity entity) => { eventsNow.AddItem("Dragging: " + entity.GetType().Name); eventsNow.scrollToEnd(); };
            UserInterface.Active.WhileMouseDown = (Entity entity) => { eventsNow.AddItem("MouseDown: " + entity.GetType().Name); eventsNow.scrollToEnd(); };
            UserInterface.Active.WhileMouseHover = (Entity entity) => { eventsNow.AddItem("MouseHover: " + entity.GetType().Name); eventsNow.scrollToEnd(); };
            eventsNow.MaxItems = 4;

            // add extra info button
            var offsetX = 140;
            Button infoBtn = new Button("  Events", anchor: Anchor.BottomLeft, size: new Vector2(280, -1), offset: new Vector2(offsetX, 0));
            infoBtn.Visible = false;
            offsetX += 280;
            infoBtn.AddChild(new Icon(IconType.Scroll, Anchor.CenterLeft), true);
            infoBtn.OnClick = (Entity entity) =>
            {
                eventsPanel.Visible = !eventsPanel.Visible;
            };
            infoBtn.ToggleMode = true;
            infoBtn.ToolTipText = "Show events log.";
            UserInterface.Active.AddEntity(infoBtn);

            // add button to enable debug mode
            Button debugBtn = new Button("Debug Mode", anchor: Anchor.BottomLeft, size: new Vector2(260, -1), offset: new Vector2(offsetX, 0));
            offsetX += 260;
            debugBtn.OnClick = (Entity entity) =>
            {
                UserInterface.Active.DebugDraw = !UserInterface.Active.DebugDraw;
            };
            debugBtn.ToggleMode = true;
            debugBtn.ToolTipText = "Enable special debug drawing mode.";
            UserInterface.Active.AddEntity(debugBtn);

            // init all examples

            if (initExamples)
            {

                // example: welcome message
                {
                    // create panel and add to list of panels and manager
                    Panel panel = new Panel(new Vector2(450, -1));
                    panels.Add(panel);
                    UserInterface.Active.AddEntity(panel);

                    // add title and text
                    panel.AddChild(new Header("Main Menu"));
                    panel.AddChild(new HorizontalLine());

                    // add default buttons
                    Button loginBtn = new Button("Login", ButtonSkin.Default);
                    loginBtn.OnClick = (Entity btn) =>
                    {
                        LoginPanel(true);
                        panel.Visible = false;
                    };
                    panel.AddChild(loginBtn);

                    Button optionsBtn = new Button("Options", ButtonSkin.Default);
                    optionsBtn.OnClick = (Entity btn) =>
                    {
                        Options(true);
                        panel.Visible = false;
                    };
                    panel.AddChild(optionsBtn);

                    Button ExitBtn = new Button("Exit", ButtonSkin.Default);
                    ExitBtn.OnClick = (Entity btn) =>
                    {
                        Exit();
                    };
                    panel.AddChild(ExitBtn);

                }

                // example: text input
                // init panels and buttons
                UpdateAfterExampleChange();

            }

            // once done init, clear events log
            eventsLog.ClearItems();

            // call base initialize
            base.Initialize();
        }

        /// <summary>
        /// Show next UI example.
        /// </summary>

        public int signup(string usuario, string contrasena)
        {
            try
            {
                IPAddress direc = IPAddress.Parse("192.168.56.102");
                IPEndPoint ipep = new IPEndPoint(direc, 9050);
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    server.Connect(ipep);

                    if (!server.Connected)
                    {
                        return -1; // Error de conexión
                    }

                    // Enviar datos de inicio de sesión
                    string mensaje = "0/" + usuario + "/" + contrasena;
                    byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // Recibir respuesta del servidor
                    byte[] msg2 = new byte[80];
                    int bytesRecibidos = server.Receive(msg2);
                    if (bytesRecibidos == 0)
                    {
                        return -1; // Error en la conexión
                    }

                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    if (mensaje == "0")
                    {
                        return 0; // Registro exitoso
                    }
                    else if (mensaje == "1")
                    {
                        return 1; // Credenciales incorrectas
                    }
                    else if (mensaje == "2")
                    {
                        return 2; // Usuario no existe
                    }
                    else if (mensaje == "3")
                    {
                        return 3; // Error en la conexión
                    }
                    else
                    {
                        return -1; // Error
                    }
                }
                catch (SocketException)
                {
                    return -1; // Error de conexión
                }
                finally
                {
                    if (server != null)
                    {
                        server.Shutdown(SocketShutdown.Both);
                        server.Close();
                    }
                }
            }
            catch (Exception)
            {
                return -1; // Error general
            }

        }
        public int login(string usuario, string contrasena)
        {
            try
            {
                IPAddress direc = IPAddress.Parse("192.168.56.102");
                IPEndPoint ipep = new IPEndPoint(direc, 9050);
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    server.Connect(ipep);

                    if (!server.Connected)
                    {
                        return -1; // Error de conexión
                    }

                    // Enviar datos de inicio de sesión
                    string mensaje = "0/" + usuario + "/" + contrasena;
                    byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // Recibir respuesta del servidor
                    byte[] msg2 = new byte[80];
                    int bytesRecibidos = server.Receive(msg2);
                    if (bytesRecibidos == 0)
                    {
                        return -1; // Error en la conexión
                    }

                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    if (mensaje == "0")
                    {
                        return 0; // Inicio de sesión exitoso
                    }
                    else if (mensaje == "1")
                    {
                        return 1; // User already exists
                    }
                    else if (mensaje == "2")
                    {
                        return 2; // Error en la conexión
                    }
                    else
                    {
                        return -1; // Error
                    }
                }
                catch (SocketException)
                {
                    return -1; // Error de conexión
                }
                finally
                {
                    if (server != null)
                    {
                        server.Shutdown(SocketShutdown.Both);
                        server.Close();
                    }
                }
            }
            catch (Exception)
            {
                return -1; // Error general
            }
        }

        public void SignUpPanel(bool visible)
        {
            // create panel and add to list of panels and manager
            Panel panel = new Panel(new Vector2(450, -1));
            panel.Visible = visible;
            panels.Add(panel);
            UserInterface.Active.AddEntity(panel);

            // text input example
            panel.AddChild(new Header("Sign Up"));
            panel.AddChild(new HorizontalLine());

            // inliner
            panel.AddChild(new Paragraph("User:"));
            TextInput text = new TextInput(false);
            text.PlaceholderText = "Insert user..";
            panel.AddChild(text);

            // with hidden password chars
            panel.AddChild(new Paragraph("Password:"));
            TextInput hiddenText = new TextInput(false);
            hiddenText.PlaceholderText = "Enter password..";
            hiddenText.HideInputWithChar = '*';
            panel.AddChild(hiddenText);

            Button backBtn = new Button("Back", ButtonSkin.Default);
            backBtn.OnClick = (Entity btn) =>
            {
                panel.Visible = false;
                panels[0].Visible = true;
            };
            panel.AddChild(backBtn);

            Button loginBtn = new Button("Login", ButtonSkin.Default);
            loginBtn.OnClick = (Entity btn) =>
            {
                LoginPanel(true);
                panel.Visible = false;
            };
            panel.AddChild(loginBtn);

            Button signupBtn = new Button("Sign Up", ButtonSkin.Default);
            signupBtn.OnClick = (Entity btn) =>
            {
                // Show the signup panel here
                string usuario = text.Value;
                string contrasena = hiddenText.Value;

                // Llamar al método login
                int result = signup(usuario, contrasena);

                // Manejar el resultado
                if (result == 0)
                {
                    conectado = true;
                    Utils.MessageBox.ShowMsgBox("Sign Up successful", "Success");
                    panel.Visible = false;
                    panels[0].Visible = true; // Volver al panel principal
                }
                else if (result == 1)
                {
                    Utils.MessageBox.ShowMsgBox("Sign Up failed", "User already exists");
                    panel.Visible = false;
                    SignUpPanel(true);
                }
                else if (result == 2)
                {
                    Utils.MessageBox.ShowMsgBox("Connection error", "Error");
                    panel.Visible = false;
                    SignUpPanel(true);
                }
                else
                {
                    Utils.MessageBox.ShowMsgBox("Connection error", "Error");
                    panel.Visible = false;
                    panels[0].Visible = true; // Volver al panel principal
                }

            };
            panel.AddChild(signupBtn);
        }
        public void LoginPanel(bool visible)
        {

            // create panel and add to list of panels and manager
            Panel panel = new Panel(new Vector2(450, -1));
            panel.Visible = visible;
            panels.Add(panel);
            UserInterface.Active.AddEntity(panel);

            // text input example
            panel.AddChild(new Header("Login"));
            panel.AddChild(new HorizontalLine());

            // inliner
            panel.AddChild(new Paragraph("User:"));
            TextInput text = new TextInput(false);
            text.PlaceholderText = "Insert user..";
            panel.AddChild(text);

            // with hidden password chars
            panel.AddChild(new Paragraph("Password:"));
            TextInput hiddenText = new TextInput(false);
            hiddenText.PlaceholderText = "Enter password..";
            hiddenText.HideInputWithChar = '*';
            panel.AddChild(hiddenText);
            var hideCheckbox = new CheckBox("Hide password", isChecked: true);
            hideCheckbox.OnValueChange += (Entity ent) =>
            {
                if (hideCheckbox.Checked)
                    hiddenText.HideInputWithChar = '*';
                else
                    hiddenText.HideInputWithChar = null;
            };
            panel.AddChild(hideCheckbox);

            Button backBtn = new Button("Back", ButtonSkin.Default);
            backBtn.OnClick = (Entity btn) =>
            {
                panel.Visible = false;
                panels[0].Visible = true;
            };
            panel.AddChild(backBtn);

            Button signupBtn = new Button("Sign Up", ButtonSkin.Default);
            signupBtn.OnClick = (Entity btn) =>
            {
                SignUpPanel(true);
                panel.Visible = false;
            };
            panel.AddChild(signupBtn);

            Button loginBtn = new Button("Login", ButtonSkin.Default);
            loginBtn.OnClick = (Entity btn) =>
            {
                string usuario = text.Value;
                string contrasena = hiddenText.Value;

                // Llamar al método login
                int result = login(usuario, contrasena);

                // Manejar el resultado
                if (result == 0)
                {
                    conectado = true;
                    Utils.MessageBox.ShowMsgBox("Login successful", "Success");
                    panel.Visible = false;
                    panels[0].Visible = true; // Volver al panel principal
                }
                else if (result == 1)
                {
                    Utils.MessageBox.ShowMsgBox("Login failed", "Invalid credentials");
                }
                else if (result == 2)
                {
                    Utils.MessageBox.ShowMsgBox("User does not exist", "Error");
                }
                else if (result == 3)
                {
                    Utils.MessageBox.ShowMsgBox("Connection error", "Error");
                }
                else
                {
                    Utils.MessageBox.ShowMsgBox("Connection error", "Error");
                }
            };
            panel.AddChild(loginBtn);
        }

        public void Options(bool visible)
        {
            // create panel and add to list of panels and manager
            // create panel and add to list of panels and manager
            Panel panel = new Panel(new Vector2(450, -1));
            panel.Visible = visible;
            panels.Add(panel);
            UserInterface.Active.AddEntity(panel);

            // sliders title
            panel.AddChild(new Header("Sliders"));
            panel.AddChild(new HorizontalLine());
            panel.AddChild(new Paragraph("Sliders help pick numeric value in range:"));

            panel.AddChild(new Paragraph("\nDefault slider"));
            {
                var slider = panel.AddChild(new Slider(-10, 10, SliderSkin.Default)) as Slider;
                var valueLabel = new Label("Value: 0");
                slider.OnValueChange = (Entity entity) =>
                {
                    valueLabel.Text = "Value: " + slider.Value;
                };
                panel.AddChild(valueLabel);
            }

            panel.AddChild(new Paragraph("\nFancy slider"));
            panel.AddChild(new Slider(0, 10, SliderSkin.Fancy));

            // progressbar title
            panel.AddChild(new LineSpace(3));
            panel.AddChild(new Header("Progress bar"));
            panel.AddChild(new HorizontalLine());
            panel.AddChild(new Paragraph("Works just like sliders:"));
            panel.AddChild(new ProgressBar(0, 10));

            Button changeThemeBtn = new Button("Change Theme", ButtonSkin.Default);
            changeThemeBtn.OnClick = (Entity entity) =>
            {
                int theme = (int)_currTheme + 1;
                if (theme > (int)BuiltinThemes.editor)
                {
                    theme = 0;
                }
                InitializeThemeAndUI((BuiltinThemes)theme);
                Options(true);
                panels[0].Visible = false;
            };
            changeThemeBtn.ToolTipText = "Rotate through the built-in themes.";
            panel.AddChild(changeThemeBtn);

            Button backBtn = new Button("Back", ButtonSkin.Default);
            backBtn.OnClick = (Entity btn) =>
            {
                panel.Visible = false;
                panels[0].Visible = true;
            };
            panel.AddChild(backBtn);
        }

        /// <summary>
        /// Called after we change current example index, to hide all examples
        /// except for the currently active example + disable prev / next buttons if
        /// needed (if first or last example).
        /// </summary>
        protected void UpdateAfterExampleChange()
        {
            // hide all panels and show current example panel
            foreach (Panel panel in panels)
            {
                panel.Visible = false;
            }
            panels[currExample].Visible = true;

            // disable / enable next and previous buttons
            nextExampleButton.Enabled = currExample != panels.Count - 1;
            previousExampleButton.Enabled = currExample != 0;
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // make sure window is focused
            if (!IsActive)
                return;

            // exit on escape
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // update UI
            UserInterface.Active.Update(gameTime);

            // show currently active entity (for testing)
            targetEntityShow.Text = "Target Entity: " + (UserInterface.Active.TargetEntity != null ? UserInterface.Active.TargetEntity.GetType().Name : "null");

            // call base update
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            // draw ui
            UserInterface.Active.Draw(spriteBatch);

            // clear buffer
            if (conectado)
                GraphicsDevice.Clear(Color.Green);
            else
                GraphicsDevice.Clear(Color.Black);


            // finalize ui rendering
            UserInterface.Active.DrawMainRenderTarget(spriteBatch);

            // call base draw function
            base.Draw(gameTime);
        }
    }
}